# Ilustrasi SIGAP

Set ilustrasi orisinal untuk SIGAP, dibuat dengan warna logo: navy `#003480` dan biru `#2F9AF8`, ditambah merah `#DC2626` untuk darurat, hijau `#16A34A` untuk aman, dan kuning tua `#D97706` untuk offline. Gaya figur manusia berupa piktogram tebal, mengikuti figur di logo. Latar transparan tanpa bentuk latar, jadi menyatu dengan warna layar apa pun. Versi dengan latar biru muda tetap disediakan di folder `alternatif-dengan-latar/` (SVG).

## Isi

| File | Layar | Teks layar yang disarankan |
| --- | --- | --- |
| onboarding-1-deteksi | Onboarding 1 | **Deteksi otomatis dari CCTV** — SIGAP mengenali saat lansia jatuh, tanpa alat yang perlu dipakai. |
| onboarding-2-notifikasi | Onboarding 2 | **Keluarga langsung diberi tahu** — Notifikasi masuk ke HP semua anggota grup dalam hitungan detik. |
| onboarding-3-aksi | Onboarding 3 | **Bertindak cepat dari HP** — Lihat kamera, bicara lewat speaker, atau telepon darurat dengan satu ketukan. |
| empty-belum-grup | Beranda tanpa grup | **Belum bergabung ke grup** — Masukkan kode undangan dari admin keluarga. [Gabung grup] |
| empty-semua-aman | Riwayat kosong | **Semua aman hari ini** — Belum ada kejadian yang terdeteksi. |
| empty-kamera-offline | Kamera tidak terhubung | **Kamera offline** — Periksa listrik dan jaringan kamera, lalu coba lagi. [Coba lagi] |
| success-ditangani | Setelah "Sudah ditangani" | **Kejadian sudah ditangani** — Anggota keluarga lain sudah diberi tahu. |
| login-app | Login aplikasi | **Masuk ke SIGAP** — Pantau keluarga tercinta dari mana saja. |
| login-web | Login web admin (800×600) | **Admin SIGAP** — Kelola grup keluarga, kamera, dan kejadian. |

## Folder

- `svg/` — semua ilustrasi dalam SVG (bisa diperbesar tanpa pecah; dipakai di React atau Flutter dengan `flutter_svg`).
- `flutter/` — PNG siap pakai dengan struktur resolusi Flutter (`name.png`, `2.0x/name.png`, `3.0x/name.png`), 400×300 pada 1x.
- `web/` — ilustrasi login web admin (SVG + PNG 2x).
- `alternatif-dengan-latar/` — versi lama dengan bentuk latar biru muda, jika suatu saat dibutuhkan.

## Cara pakai

Flutter (`pubspec.yaml`):

```yaml
flutter:
  assets:
    - assets/illustrations/
```

Salin isi folder `flutter/` ke `mobile/assets/illustrations/`, lalu:

```dart
Image.asset('assets/illustrations/empty-semua-aman.png', width: 260)
```

React: salin `svg/` ke `web/src/assets/illustrations/`, lalu:

```jsx
import loginArt from './assets/illustrations/login-web.svg';
<img src={loginArt} alt="" className="w-full max-w-lg" />
```

Ilustrasi bersifat dekoratif, jadi beri `alt=""` di web dan `excludeFromSemantics: true` di Flutter.

## Lisensi

Ilustrasi ini dibuat khusus untuk tim SIGAP dan bebas dipakai serta diubah. Catat di README repo sebagai aset buatan tim.
